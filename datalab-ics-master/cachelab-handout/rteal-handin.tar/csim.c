//Written by Rachel Teal, Heather Dalton, and Owen Elliott

#include "cachelab.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>

// typedef struct Line {
//     char validBit;
//     int blockSize, lastAccessed, startingAddress;

//     void initLine(int newStartingAddress, int newLastAccessed, int newBlockSize) {
//         blockSize = newBlockSize;
//         startingAddress = newStartingAddress;
//         validBit = 0;
//         lastAccessed = newLastAccessed;
//     }
// } Line;

// typedef struct Set {
//     int setNum;
//     Line* lineArray[];
// } Set;

// typedef struct Cache {
//     int recentlyUsedCounter;
//     Set* setArray[];

//     void initCache(int numSets, int numLines, int byteSize) {
//         recentlyUsedCounter = 0;
//     }
// } Cache;

/* Simple types for an address and for the value of the LRU counter */
typedef unsigned long mem_addr_t;
typedef unsigned long lru_t;
/* One cache line */
typedef struct {
  char valid;					/* Non-zero means line is valid */
  mem_addr_t tag;				/* Tag bits from address */
  lru_t lru;					/* Least-recently-used value */
} cache_line_t;

/* One cache set: an array of E cache lines */
typedef cache_line_t* cache_set_t;
/* One cache: an array of S cache sets */
typedef cache_set_t* cache_t;


int main(int argc, char *argv[])
{
    //Parse command arguments
    int opt;
    int sets, lines, blocks;
    lru_t lru_counter;
    char *path;
    
    sets=-1;
    lines=-1;
    blocks=-1;
    lru_counter = 0;

    printf("argc: %d\n", argc);

    if(argc < 9){
        printf("Missing arguments.\n");
        exit(1);
    }

    if(argc > 11){
        printf("Too many arguments.\n");
        exit(1);
    }

    while((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1){
        switch(opt){
            case 'v':
                printf("Verbose Unimplemented\n");
                break;
            case 's':
                sets = atoi(optarg);
                break;
            case 'E':
                lines = atoi(optarg);
                break;
            case 'b':
                blocks = atoi(optarg);
                break;
            case 't':
                path = optarg;
                break;
            default:
            case 'h':
                printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n"
                    "Options:\n"
                    "-h         Print this help message.\n"
                    "-v         Optional verbose flag.\n"
                    "-s <num>   Number of set index bits.\n"
                    "-E <num>   Number of lines per set.\n"
                    "-b <num>   Number of block offset bits.\n"
                    "-t <file>  Trace file.\n"
                    "\n"
                    "Examples:\n"
                    "linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n"
                    "linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n"
                );
                exit(1);
        }
    }

    if(sets < 0){
        printf("Invalid -s argument.\n");
        exit(1);
    }
    if(lines < 1){
        printf("Invalid -E argument.\n");
        exit(1);
    }
    if(blocks < 0){
        printf("Invalid -b argument.\n");
        exit(1);
    }


    printf("Sets: %d; Lines: %d, Blocks: %d, Path: %s\n", 
        sets, lines, blocks, path);


    /* How to allocate cache lines for one set. Generalize! */
	
    cache_t cache = malloc(sets * sizeof(cache_set_t));
    //malloc((sets*lines*sizeof(cache_line_t))+(sizeof(cache_set_t)*sets))
    //malloc(sets * sizeof(one_set))
    //malloc(sets*lines*sizeof(cache_set_t))

    for (int i = 0; i < sets; i++) {
        cache_set_t this_set = malloc(lines * sizeof(cache_line_t));

        //Default vals here
        for (int j = 0; j < lines; j++) {
            this_set[j].valid = 0;
            //this_set[j].tag = j;
            this_set[j].lru = lru_counter;
        }

        cache[i] = this_set;
        //free(this_set);
    }

    
    /* How to read from the trace file. */
    char operation;				/* The operation (I, L, S, M) */
	mem_addr_t address;			/* The address (in hex) */
	int size;					/* The size of the operation */

        //Open trace file
    FILE *fptr;
    
    if((fptr=fopen(path, "r"))== NULL){
        printf("Failed to open file!\n");
        exit(1);
    }
    
    while (fscanf(fptr, " %c %lx,%x\n", &operation, &address, &size) != EOF) {
        printf("%c %lx %x\n", operation, address, size);
        mem_addr_t mem_addr = address;
        int tag = mem_addr >> (blocks + sets);
        int set = mem_addr >> blocks;

        printf("tag: %d, set: %d", tag, set);

        cache[set][tag].valid = '1';
        // cache[0][0].valid = '1';
        printf("%c \n", cache[set][tag].valid);
            //get mem address and turn into cache address
            //This may depend on size of cache params!

            // If L (data load) hit if present, miss if not
                // Modify if miss?
            // If S (data store) if space taken, evict
                //if empty, just load value???
            // If M (data modify)  hit if present, miss if not
                //if hit, evict/modify?
	}
	fclose(fptr);

	/* How to free the cache lines. Generalize! */
    free(cache);

    fclose(fptr);
    //call printSummary with counters
    printSummary(0, 0, 0); // Hits, misses, evictions
    return 0;
}